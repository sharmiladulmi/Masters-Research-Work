## Customer behaviour analysis and quotation success prediction using machine learning for sales optimization


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
```

##### Inspect Dataset


```python
df = pd.read_csv('Quotation.csv', encoding='ISO-8859-1')  
df.head()
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 216294 entries, 0 to 216293
    Data columns (total 41 columns):
     #   Column                        Non-Null Count   Dtype  
    ---  ------                        --------------   -----  
     0   Name                          216294 non-null  object 
     1   Creation                      216294 non-null  object 
     2   Modified                      216294 non-null  object 
     3   Docstatus                     216294 non-null  int64  
     4   Customer Name                 216294 non-null  object 
     5   Transaction Date              216294 non-null  object 
     6   Address Display               189486 non-null  object 
     7   Customer Group                216177 non-null  object 
     8   Total Qty                     216294 non-null  float64
     9   Base Net Total                216294 non-null  float64
     10  Base Total Taxes And Charges  216294 non-null  float64
     11  Base Grand Total              216294 non-null  float64
     12  Status                        216294 non-null  object 
     13  Payment Type                  216294 non-null  object 
     14  Total Cost ($)                216294 non-null  float64
     15  Account Manager Name          215772 non-null  object 
     16  Sales Manager Name            215772 non-null  object 
     17  Department                    214422 non-null  object 
     18  Creation.1                    86693 non-null   object 
     19  Modified.1                    86693 non-null   object 
     20  Lost Reason                   86693 non-null   object 
     21  Item Code                     216294 non-null  object 
     22  Item Name                     216294 non-null  object 
     23  Item Group                    216294 non-null  object 
     24  Brand                         212744 non-null  object 
     25  Qty                           216294 non-null  float64
     26  Stock Uom                     216294 non-null  object 
     27  Stock Qty                     216294 non-null  float64
     28  Price List Rate               216294 non-null  float64
     29  Discount Percentage ($)       216294 non-null  float64
     30  Discount Amount ($)           216294 non-null  float64
     31  Base Net Amount               216294 non-null  float64
     32  Warehouse                     216294 non-null  object 
     33  Projected Qty                 216294 non-null  float64
     34  Actual Qty                    216294 non-null  float64
     35  Total Qty.1                   216294 non-null  float64
     36  Item Vailability              216294 non-null  object 
     37  Item Cost ($)                 216294 non-null  float64
     38  Total Cost ($).1              216294 non-null  float64
     39  Margin ($)                    216294 non-null  float64
     40  Stocking Status               195981 non-null  object 
    dtypes: float64(17), int64(1), object(23)
    memory usage: 67.7+ MB
    


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Creation</th>
      <th>Modified</th>
      <th>Docstatus</th>
      <th>Customer Name</th>
      <th>Transaction Date</th>
      <th>Address Display</th>
      <th>Customer Group</th>
      <th>Total Qty</th>
      <th>Base Net Total</th>
      <th>...</th>
      <th>Base Net Amount</th>
      <th>Warehouse</th>
      <th>Projected Qty</th>
      <th>Actual Qty</th>
      <th>Total Qty.1</th>
      <th>Item Vailability</th>
      <th>Item Cost ($)</th>
      <th>Total Cost ($).1</th>
      <th>Margin ($)</th>
      <th>Stocking Status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>SAL-QTN-2022-00021</td>
      <td>April 18, 2022, 11:26 AM</td>
      <td>August 29, 2022, 8:40 AM</td>
      <td>1</td>
      <td>Richard Peiris  Tyre Co Ltd</td>
      <td>6-Apr-22</td>
      <td>P O Box 16, Nawinna,&lt;br&gt;Maharagama&lt;br&gt;\nSri La...</td>
      <td>Manufacturing</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>...</td>
      <td>3616.0</td>
      <td>Issuing-C-Bin-CF8 - ESL</td>
      <td>117.0</td>
      <td>117.0</td>
      <td>117.0</td>
      <td>Available</td>
      <td>991.80</td>
      <td>1983.60</td>
      <td>45.14</td>
      <td>Stock</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SAL-QTN-2022-00021</td>
      <td>April 18, 2022, 11:26 AM</td>
      <td>August 29, 2022, 8:40 AM</td>
      <td>1</td>
      <td>Richard Peiris  Tyre Co Ltd</td>
      <td>6-Apr-22</td>
      <td>P O Box 16, Nawinna,&lt;br&gt;Maharagama&lt;br&gt;\nSri La...</td>
      <td>Manufacturing</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>...</td>
      <td>3864.0</td>
      <td>Issuing-A-Bin-AC6 - ESL</td>
      <td>26.0</td>
      <td>26.0</td>
      <td>74.0</td>
      <td>Available</td>
      <td>2124.19</td>
      <td>2124.19</td>
      <td>45.03</td>
      <td>Stock</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SAL-QTN-2022-00021</td>
      <td>April 18, 2022, 11:26 AM</td>
      <td>August 29, 2022, 8:40 AM</td>
      <td>1</td>
      <td>Richard Peiris  Tyre Co Ltd</td>
      <td>6-Apr-22</td>
      <td>P O Box 16, Nawinna,&lt;br&gt;Maharagama&lt;br&gt;\nSri La...</td>
      <td>Manufacturing</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>...</td>
      <td>912.0</td>
      <td>Issuing-D-Bin-DF10 - ESL</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>50.0</td>
      <td>Available</td>
      <td>251.94</td>
      <td>503.88</td>
      <td>44.75</td>
      <td>Stock</td>
    </tr>
    <tr>
      <th>3</th>
      <td>SAL-QTN-2022-00022</td>
      <td>April 18, 2022, 12:59 PM</td>
      <td>August 17, 2022, 8:25 PM</td>
      <td>1</td>
      <td>Srilankan Airlines Ltd</td>
      <td>18-Apr-22</td>
      <td>NaN</td>
      <td>All Customer Groups</td>
      <td>2.0</td>
      <td>7845.0</td>
      <td>...</td>
      <td>3855.0</td>
      <td>Issuing-C-Bin-CA4 - ESL</td>
      <td>18.0</td>
      <td>18.0</td>
      <td>98.0</td>
      <td>Available</td>
      <td>2055.28</td>
      <td>2055.28</td>
      <td>46.69</td>
      <td>Stock</td>
    </tr>
    <tr>
      <th>4</th>
      <td>SAL-QTN-2022-00022</td>
      <td>April 18, 2022, 12:59 PM</td>
      <td>August 17, 2022, 8:25 PM</td>
      <td>1</td>
      <td>Srilankan Airlines Ltd</td>
      <td>18-Apr-22</td>
      <td>NaN</td>
      <td>All Customer Groups</td>
      <td>2.0</td>
      <td>7845.0</td>
      <td>...</td>
      <td>3990.0</td>
      <td>Issuing-A-Bin-AC6 - ESL</td>
      <td>25.0</td>
      <td>26.0</td>
      <td>74.0</td>
      <td>Available</td>
      <td>2124.19</td>
      <td>2124.19</td>
      <td>46.76</td>
      <td>Stock</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 41 columns</p>
</div>




```python
# Distribution of accepted vs. rejected quotations
sns.countplot(x='Status', data=df)
plt.show()
```


    
![png](output_5_0.png)
    


##### Data Cleaning


```python
# Remove Cancelled and Draft Quotations
df1 = df[df['Docstatus'] == 1]
```


```python
categories = df1['Status'].unique().tolist()
print(categories)
```

    ['Lost', 'Ordered', 'Expired', 'Open']
    


```python
# Convert to datetime format
df['Creation'] = pd.to_datetime(df['Creation'], errors='coerce')
df['Modified'] = pd.to_datetime(df['Modified'], errors='coerce')
```


```python
# Handle missing values
df1 = df1.fillna('Unknown')
```


```python
from sklearn.preprocessing import LabelEncoder

# List of columns to encode
columns_to_encode = ['Customer Group', 'Payment Type', 'Department', 'Brand', 'Stock Uom', 'Status', 'Lost Reason', 'Item Group', 'Stocking Status','Item Vailability']

label_encoders = {}
for col in columns_to_encode:
    le = LabelEncoder()
    df1[col] = le.fit_transform(df1[col].astype(str))  # Convert to string before encoding
    label_encoders[col] = le
```


```python
print(df1.dtypes)
```

    Name                             object
    Creation                         object
    Modified                         object
    Docstatus                         int64
    Customer Name                    object
    Transaction Date                 object
    Address Display                  object
    Customer Group                    int32
    Total Qty                       float64
    Base Net Total                  float64
    Base Total Taxes And Charges    float64
    Base Grand Total                float64
    Status                            int32
    Payment Type                      int32
    Total Cost ($)                  float64
    Account Manager Name             object
    Sales Manager Name               object
    Department                        int32
    Creation.1                       object
    Modified.1                       object
    Lost Reason                       int32
    Item Code                        object
    Item Name                        object
    Item Group                        int32
    Brand                             int32
    Qty                             float64
    Stock Uom                         int32
    Stock Qty                       float64
    Price List Rate                 float64
    Discount Percentage ($)         float64
    Discount Amount ($)             float64
    Base Net Amount                 float64
    Warehouse                        object
    Projected Qty                   float64
    Actual Qty                      float64
    Total Qty.1                     float64
    Item Vailability                  int32
    Item Cost ($)                   float64
    Total Cost ($).1                float64
    Margin ($)                      float64
    Stocking Status                   int32
    dtype: object
    

##### Feature Engineering

###### Date Based Features


```python
df1['Creation'] = pd.to_datetime(df1['Creation'])
df1['Modified'] = pd.to_datetime(df1['Modified'])

# Create new column with the difference in days
df1['Quotation_Duration'] = (df1['Modified'] - df1['Creation']).dt.days
```

###### Customer Behaviour Features


```python
# Create a binary column for success-like statuses ('Open' or 'Ordered')
df1['Is_Loyal'] = df1['Status'].isin(['Open', 'Ordered']).astype(int)

# Group by 'Customer Name' and calculate sum and count
loyalty = df1.groupby('Customer Name').agg(
    Loyalty_Numerator=('Is_Loyal', 'sum'),
    Total_Quotations=('Name', 'count')  # Assuming 'Name' is the quotation ID or similar
).reset_index()

# Calculate the Customer Loyalty Score
loyalty['Customer_Loyalty_Score'] = loyalty['Loyalty_Numerator'] / loyalty['Total_Quotations']

# Merge back into original dataframe
df1 = df1.merge(loyalty[['Customer Name', 'Customer_Loyalty_Score']], on='Customer Name', how='left')
```

###### Financial Ratios


```python
df1['Discount_Percentage'] = df1['Discount Amount ($)'] / df1['Price List Rate']
df1['Discount_Percentage'] = df1['Discount Amount ($)'] / df1['Price List Rate'].replace(0, pd.NA)
```


```python
df1['Margin_Percentage'] = df1['Margin ($)'] / df1['Base Net Amount']
df1['Margin_Percentage'] = df1['Margin ($)'] / df1['Base Net Amount'].replace(0, pd.NA)
```


```python
df1['Cost_to_Value_Ratio'] = df1['Item Cost ($)'] / df1['Base Net Amount']
df1['Cost_to_Value_Ratio'] = df1['Item Cost ($)'] / df1['Base Net Amount'].replace(0, pd.NA)
```

###### Item Features


```python
# Create a success flag based on 'Status'
df1['Is_Success'] = df1['Status'].isin(['Open', 'Ordered']).astype(int)

# Group by Item Code and compute required metrics
item_grouped = df1.groupby('Item Code').agg(
    Average_Item_Discount=('Discount Amount ($)', 'mean'),
    Average_Item_Margin=('Margin ($)', 'mean'),
    Quotes_Won=('Is_Success', 'count'),
    Total_Quotes=('Name', 'count')  # Assuming 'Name' is quotation ID
).reset_index()

# Calculate success rate
item_grouped['Item_Success_Rate'] = item_grouped['Quotes_Won'] / item_grouped['Total_Quotes']
```


```python
df1 = df1.merge(item_grouped[['Item Code', 'Average_Item_Discount', 'Average_Item_Margin', 'Item_Success_Rate']], 
                on='Item Code', how='left')
```

###### Manager / Department Based


```python
df1['Account Manager Name'] = df1['Account Manager Name'].astype('category')
df1['Sales Manager Name'] = df1['Sales Manager Name'].astype('category')
df1['Department'] = df1['Department'].astype('category')
```


```python
# Group by Account Manager
account_manager_perf = df1.groupby('Account Manager Name').agg(
    Total_Quotes=('Name', 'count'),
    Quotes_Won=('Is_Success', 'sum')
).reset_index()

account_manager_perf['Success_Rate'] = account_manager_perf['Quotes_Won'] / account_manager_perf['Total_Quotes']
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\719442807.py:2: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      account_manager_perf = df1.groupby('Account Manager Name').agg(
    


```python
# Group by Sales Manager
sales_manager_perf = df1.groupby('Sales Manager Name').agg(
    Total_Quotes=('Name', 'count'),
    Quotes_Won=('Is_Success', 'sum')
).reset_index()

sales_manager_perf['Success_Rate'] = sales_manager_perf['Quotes_Won'] / sales_manager_perf['Total_Quotes']
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\1968315563.py:2: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      sales_manager_perf = df1.groupby('Sales Manager Name').agg(
    


```python
# Group by Department
dept_perf = df1.groupby('Department').agg(
    Total_Quotes=('Name', 'count'),
    Quotes_Won=('Is_Success', 'sum')
).reset_index()

dept_perf['Success_Rate'] = dept_perf['Quotes_Won'] / dept_perf['Total_Quotes']
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3881183125.py:2: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      dept_perf = df1.groupby('Department').agg(
    


```python
df1 = df1.merge(account_manager_perf[['Account Manager Name', 'Success_Rate']], on='Account Manager Name', how='left', suffixes=('', '_Manager'))
```

###### Stock & Availability


```python
df1['Stock_Shortage'] = df1['Projected Qty'] - df1['Actual Qty']
```


```python
df1['Stock_Shortage'] = df1['Projected Qty'].fillna(0) - df1['Actual Qty'].fillna(0)
```

##### Feature Extraction


```python
pip install pandas scikit-learn matplotlib seaborn
```

    Requirement already satisfied: pandas in c:\users\dell\anaconda3\lib\site-packages (2.2.2)
    Requirement already satisfied: scikit-learn in c:\users\dell\anaconda3\lib\site-packages (1.5.1)
    Requirement already satisfied: matplotlib in c:\users\dell\anaconda3\lib\site-packages (3.9.2)
    Requirement already satisfied: seaborn in c:\users\dell\anaconda3\lib\site-packages (0.13.2)
    Requirement already satisfied: numpy>=1.26.0 in c:\users\dell\anaconda3\lib\site-packages (from pandas) (1.26.4)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\dell\anaconda3\lib\site-packages (from pandas) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\dell\anaconda3\lib\site-packages (from pandas) (2024.1)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\dell\anaconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: scipy>=1.6.0 in c:\users\dell\anaconda3\lib\site-packages (from scikit-learn) (1.13.1)
    Requirement already satisfied: joblib>=1.2.0 in c:\users\dell\anaconda3\lib\site-packages (from scikit-learn) (1.4.2)
    Requirement already satisfied: threadpoolctl>=3.1.0 in c:\users\dell\anaconda3\lib\site-packages (from scikit-learn) (3.5.0)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (1.2.0)
    Requirement already satisfied: cycler>=0.10 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (4.51.0)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (24.1)
    Requirement already satisfied: pillow>=8 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (10.4.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\dell\anaconda3\lib\site-packages (from matplotlib) (3.1.2)
    Requirement already satisfied: six>=1.5 in c:\users\dell\anaconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
df1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Creation</th>
      <th>Modified</th>
      <th>Docstatus</th>
      <th>Customer Name</th>
      <th>Transaction Date</th>
      <th>Address Display</th>
      <th>Customer Group</th>
      <th>Total Qty</th>
      <th>Base Net Total</th>
      <th>...</th>
      <th>Customer_Loyalty_Score</th>
      <th>Discount_Percentage</th>
      <th>Margin_Percentage</th>
      <th>Cost_to_Value_Ratio</th>
      <th>Is_Success</th>
      <th>Average_Item_Discount</th>
      <th>Average_Item_Margin</th>
      <th>Item_Success_Rate</th>
      <th>Success_Rate</th>
      <th>Stock_Shortage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>SAL-QTN-2022-00021</td>
      <td>2022-04-18 11:26:00</td>
      <td>2022-08-29 08:40:00</td>
      <td>1</td>
      <td>Richard Peiris  Tyre Co Ltd</td>
      <td>6-Apr-22</td>
      <td>P O Box 16, Nawinna,&lt;br&gt;Maharagama&lt;br&gt;\nSri La...</td>
      <td>7</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.270968</td>
      <td>0.012483</td>
      <td>0.274281</td>
      <td>0</td>
      <td>1551.103684</td>
      <td>29.510526</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>SAL-QTN-2022-00021</td>
      <td>2022-04-18 11:26:00</td>
      <td>2022-08-29 08:40:00</td>
      <td>1</td>
      <td>Richard Peiris  Tyre Co Ltd</td>
      <td>6-Apr-22</td>
      <td>P O Box 16, Nawinna,&lt;br&gt;Maharagama&lt;br&gt;\nSri La...</td>
      <td>7</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.273684</td>
      <td>0.011654</td>
      <td>0.549739</td>
      <td>0</td>
      <td>2755.487123</td>
      <td>-68.306472</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>SAL-QTN-2022-00021</td>
      <td>2022-04-18 11:26:00</td>
      <td>2022-08-29 08:40:00</td>
      <td>1</td>
      <td>Richard Peiris  Tyre Co Ltd</td>
      <td>6-Apr-22</td>
      <td>P O Box 16, Nawinna,&lt;br&gt;Maharagama&lt;br&gt;\nSri La...</td>
      <td>7</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.27619</td>
      <td>0.049068</td>
      <td>0.276250</td>
      <td>0</td>
      <td>374.965796</td>
      <td>32.872449</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>SAL-QTN-2022-00022</td>
      <td>2022-04-18 12:59:00</td>
      <td>2022-08-17 20:25:00</td>
      <td>1</td>
      <td>Srilankan Airlines Ltd</td>
      <td>18-Apr-22</td>
      <td>Unknown</td>
      <td>0</td>
      <td>2.0</td>
      <td>7845.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.25</td>
      <td>0.012112</td>
      <td>0.533147</td>
      <td>0</td>
      <td>2633.625785</td>
      <td>-120.563720</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>SAL-QTN-2022-00022</td>
      <td>2022-04-18 12:59:00</td>
      <td>2022-08-17 20:25:00</td>
      <td>1</td>
      <td>Srilankan Airlines Ltd</td>
      <td>18-Apr-22</td>
      <td>Unknown</td>
      <td>0</td>
      <td>2.0</td>
      <td>7845.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.25</td>
      <td>0.011719</td>
      <td>0.532378</td>
      <td>0</td>
      <td>2755.487123</td>
      <td>-68.306472</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 53 columns</p>
</div>




```python
df1.head()
df1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 139080 entries, 0 to 139079
    Data columns (total 53 columns):
     #   Column                        Non-Null Count   Dtype         
    ---  ------                        --------------   -----         
     0   Name                          139080 non-null  object        
     1   Creation                      139080 non-null  datetime64[ns]
     2   Modified                      139080 non-null  datetime64[ns]
     3   Docstatus                     139080 non-null  int64         
     4   Customer Name                 139080 non-null  object        
     5   Transaction Date              139080 non-null  object        
     6   Address Display               139080 non-null  object        
     7   Customer Group                139080 non-null  int32         
     8   Total Qty                     139080 non-null  float64       
     9   Base Net Total                139080 non-null  float64       
     10  Base Total Taxes And Charges  139080 non-null  float64       
     11  Base Grand Total              139080 non-null  float64       
     12  Status                        139080 non-null  int32         
     13  Payment Type                  139080 non-null  int32         
     14  Total Cost ($)                139080 non-null  float64       
     15  Account Manager Name          139080 non-null  category      
     16  Sales Manager Name            139080 non-null  category      
     17  Department                    139080 non-null  category      
     18  Creation.1                    139080 non-null  object        
     19  Modified.1                    139080 non-null  object        
     20  Lost Reason                   139080 non-null  int32         
     21  Item Code                     139080 non-null  object        
     22  Item Name                     139080 non-null  object        
     23  Item Group                    139080 non-null  int32         
     24  Brand                         139080 non-null  int32         
     25  Qty                           139080 non-null  float64       
     26  Stock Uom                     139080 non-null  int32         
     27  Stock Qty                     139080 non-null  float64       
     28  Price List Rate               139080 non-null  float64       
     29  Discount Percentage ($)       139080 non-null  float64       
     30  Discount Amount ($)           139080 non-null  float64       
     31  Base Net Amount               139080 non-null  float64       
     32  Warehouse                     139080 non-null  object        
     33  Projected Qty                 139080 non-null  float64       
     34  Actual Qty                    139080 non-null  float64       
     35  Total Qty.1                   139080 non-null  float64       
     36  Item Vailability              139080 non-null  int32         
     37  Item Cost ($)                 139080 non-null  float64       
     38  Total Cost ($).1              139080 non-null  float64       
     39  Margin ($)                    139080 non-null  float64       
     40  Stocking Status               139080 non-null  int32         
     41  Quotation_Duration            139080 non-null  int64         
     42  Is_Loyal                      139080 non-null  int32         
     43  Customer_Loyalty_Score        139080 non-null  float64       
     44  Discount_Percentage           137094 non-null  object        
     45  Margin_Percentage             139080 non-null  float64       
     46  Cost_to_Value_Ratio           139080 non-null  float64       
     47  Is_Success                    139080 non-null  int32         
     48  Average_Item_Discount         139080 non-null  float64       
     49  Average_Item_Margin           139080 non-null  float64       
     50  Item_Success_Rate             139080 non-null  float64       
     51  Success_Rate                  139080 non-null  float64       
     52  Stock_Shortage                139080 non-null  float64       
    dtypes: category(3), datetime64[ns](2), float64(25), int32(11), int64(2), object(10)
    memory usage: 47.6+ MB
    

#### Mutual Information for Feature Selection


```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import SelectKBest, mutual_info_classif

# Define irrelevant columns (metadata, IDs, timestamps)
irrelevant_cols = [
    'Name', 'Creation', 'Modified', 'Customer Name', 'Transaction Date',
    'Address Display', 'Creation.1', 'Modified.1', 'Lost Reason'
]

# Define engineered numeric columns (informative)
engineered_numeric_cols = [
    'quotation duration', 'customer loyalty score', 'discount percentage',
    'margin percentage', 'cost to value ratio', 'item success rate',
    'success rate', 'stock shortage'
]

# Create df2 by removing irrelevant columns from df1
df2 = df1.drop(columns=[col for col in irrelevant_cols if col in df1.columns])

# Convert engineered numeric columns to numeric in df2
for col in engineered_numeric_cols:
    if col in df2.columns:
        df2[col] = pd.to_numeric(df2[col], errors='coerce')

# Handle missing values
for col in df2.columns:
    if pd.api.types.is_numeric_dtype(df2[col]):
        df2[col] = df2[col].fillna(0)
    else:
        df2[col] = df2[col].astype(str).fillna('Unknown')

# Encode categorical features
label_encoders = {}
for col in df2.columns:
    if df2[col].dtype == 'object':
        le = LabelEncoder()
        df2[col] = le.fit_transform(df2[col])
        label_encoders[col] = le

# Separate target (status) and features in df2
target_col = 'Status'
if target_col not in df2.columns:
    raise KeyError(f"'{target_col}' column is not found in the dataset.")

y = df2[target_col]
X = df2.drop(columns=[target_col])

# Apply Mutual Information to df2
mi_selector = SelectKBest(score_func=mutual_info_classif, k='all')
mi_selector.fit(X, y)
mi_scores = mi_selector.scores_

# Create score DataFrame for df2
mi_results = pd.DataFrame({
    'Feature': X.columns,
    'MI Score': mi_scores
}).sort_values(by='MI Score', ascending=False)

# Plot top N features from df2
top_n = 25
plt.figure(figsize=(12, 8))
sns.barplot(data=mi_results.head(top_n), x='MI Score', y='Feature', palette='viridis')
plt.title(f'Top {top_n} Features by Mutual Information (df2)')
plt.xlabel('Mutual Information Score')
plt.ylabel('Feature')

# Add score labels on the bars
for index, row in mi_results.head(top_n).iterrows():
    plt.text(row['MI Score'] + 0.01, index - mi_results.head(top_n).index[0], f"{row['MI Score']:.2f}", va='center')

plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3772830455.py:65: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=mi_results.head(top_n), x='MI Score', y='Feature', palette='viridis')
    


    
![png](output_39_1.png)
    



```python
# Threshold value is 0.05
significant_features = mi_results[mi_results['MI Score'] > 0.05]['Feature'].tolist()
print("Significant features (MI Score > 0.05):")
print(significant_features)
```

    Significant features (MI Score > 0.05):
    ['Total Cost ($)', 'Base Grand Total', 'Base Net Total', 'Base Total Taxes And Charges', 'Quotation_Duration', 'Account Manager Name', 'Discount Amount ($)', 'Sales Manager Name', 'Cost_to_Value_Ratio', 'Total Qty', 'Margin ($)', 'Base Net Amount', 'Price List Rate', 'Item Cost ($)', 'Total Cost ($).1', 'Margin_Percentage', 'Discount_Percentage', 'Discount Percentage ($)']
    


```python
df2.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Docstatus</th>
      <th>Customer Group</th>
      <th>Total Qty</th>
      <th>Base Net Total</th>
      <th>Base Total Taxes And Charges</th>
      <th>Base Grand Total</th>
      <th>Status</th>
      <th>Payment Type</th>
      <th>Total Cost ($)</th>
      <th>Account Manager Name</th>
      <th>...</th>
      <th>Customer_Loyalty_Score</th>
      <th>Discount_Percentage</th>
      <th>Margin_Percentage</th>
      <th>Cost_to_Value_Ratio</th>
      <th>Is_Success</th>
      <th>Average_Item_Discount</th>
      <th>Average_Item_Margin</th>
      <th>Item_Success_Rate</th>
      <th>Success_Rate</th>
      <th>Stock_Shortage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>7</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>671.36</td>
      <td>9063.36</td>
      <td>1</td>
      <td>1</td>
      <td>4611.67</td>
      <td>13</td>
      <td>...</td>
      <td>0.0</td>
      <td>1694</td>
      <td>0.012483</td>
      <td>0.274281</td>
      <td>0</td>
      <td>1551.103684</td>
      <td>29.510526</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>7</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>671.36</td>
      <td>9063.36</td>
      <td>1</td>
      <td>1</td>
      <td>4611.67</td>
      <td>13</td>
      <td>...</td>
      <td>0.0</td>
      <td>1757</td>
      <td>0.011654</td>
      <td>0.549739</td>
      <td>0</td>
      <td>2755.487123</td>
      <td>-68.306472</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>7</td>
      <td>5.0</td>
      <td>8392.0</td>
      <td>671.36</td>
      <td>9063.36</td>
      <td>1</td>
      <td>1</td>
      <td>4611.67</td>
      <td>13</td>
      <td>...</td>
      <td>0.0</td>
      <td>1829</td>
      <td>0.049068</td>
      <td>0.276250</td>
      <td>0</td>
      <td>374.965796</td>
      <td>32.872449</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>2.0</td>
      <td>7845.0</td>
      <td>627.60</td>
      <td>8472.60</td>
      <td>1</td>
      <td>1</td>
      <td>4179.47</td>
      <td>23</td>
      <td>...</td>
      <td>0.0</td>
      <td>1500</td>
      <td>0.012112</td>
      <td>0.533147</td>
      <td>0</td>
      <td>2633.625785</td>
      <td>-120.563720</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>2.0</td>
      <td>7845.0</td>
      <td>627.60</td>
      <td>8472.60</td>
      <td>1</td>
      <td>1</td>
      <td>4179.47</td>
      <td>23</td>
      <td>...</td>
      <td>0.0</td>
      <td>1500</td>
      <td>0.011719</td>
      <td>0.532378</td>
      <td>0</td>
      <td>2755.487123</td>
      <td>-68.306472</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>-1.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 44 columns</p>
</div>



#### Chi Suqare Test for Feature Selection


```python
from sklearn.feature_selection import SelectKBest, chi2
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Make a copy of the original DataFrame
df3 = df1.copy()

# Filter only finalized quotations (docstatus = 1)
df3 = df3[df3['Docstatus'] == 1].copy()

# Drop irrelevant or text-heavy/date columns
drop_cols = [
    'Name', 'Creation', 'Modified', 'Customer Name', 'Transaction Date',
    'Address Display', 'Creation.1', 'Modified.1', 'Account Manager Name',
    'Sales Manager Name', 'Lost Reason'
]
df3 = df3.drop(columns=drop_cols, errors='ignore')

# Clean column names
df3.columns = df3.columns.str.strip().str.lower().str.replace(' ', '_')

# Define features and target
if 'status' in df3.columns:
    y = df3['status']
    X = df3.drop(columns=['status'])
else:
    raise KeyError("The target column 'status' was not found in the DataFrame.")

# Convert to numeric and clip negative values
X = X.apply(pd.to_numeric, errors='coerce').fillna(0)
X = X.clip(lower=0)

# Apply Chi-Square Feature Selection
chi2_selector = SelectKBest(score_func=chi2, k='all')
chi2_selector.fit(X, y)

# Extract scores and p-values
chi2_scores = chi2_selector.scores_
chi2_pvalues = chi2_selector.pvalues_

# Create DataFrame with scores and p-values
chi2_results = pd.DataFrame({
    'Feature': X.columns,
    'Chi2 Score': chi2_scores,
    'p-value': chi2_pvalues
}).sort_values(by='Chi2 Score', ascending=False)

# Plot the top N features
top_n = 25
plt.figure(figsize=(14, 7))
ax = sns.barplot(
    data=chi2_results.head(top_n),
    x='Chi2 Score',
    y='Feature',
    palette='viridis'
)

# Annotate bars with p-values
for i, row in chi2_results.head(top_n).iterrows():
    p_val = f"{row['p-value']:.3e}"  # scientific notation
    ax.text(
        row['Chi2 Score'] + 0.5,
        i - chi2_results.head(top_n).index[0],
        f"p={p_val}",
        va='center',
        fontsize=9,
        color='black'
    )

plt.title(f'Top {top_n} Features by Chi-Square Test with p-values')
plt.xlabel('Chi-Square Score')
plt.ylabel('Feature')
plt.tight_layout()
plt.show()

```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3399528264.py:52: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      ax = sns.barplot(
    


    
![png](output_43_1.png)
    



```python
chi2_results = pd.DataFrame({
    'Feature': X.columns,
    'Chi2 Score': chi2_scores,
    'p-value': chi2_pvalues
}).sort_values(by='Chi2 Score', ascending=False)

```


```python
# P-Value < 0.05 features, threshold value is 0.05
print(chi2_results.head())
```

                             Feature    Chi2 Score  p-value
    5               base_grand_total  7.753636e+09      0.0
    3                 base_net_total  6.800454e+09      0.0
    4   base_total_taxes_and_charges  9.689807e+08      0.0
    19               base_net_amount  9.003847e+08      0.0
    7                 total_cost_($)  5.880088e+08      0.0
    

##### Both the Chi-Square test and the Mutual Information method yielded similar results in terms of feature importance. The commonly selected features from both tests are as follows:  

Total Cost, Base Grand Total, Base Net Total, Base Total Taxes And Charges, Quotation Duration, Account Manager Name, Sales Manager Name, Discount Amount, Cost to Value Ratio, Total Qty, Margin, Price List Rate, Base Net Amount, Item Cost.1, Margin Percentage, Discount Percentage, Discount Percentage($) 

#### Machine Learning Models Application for Predict the Quotation Success


```python
# Define the list of columns you want to keep
selected_columns = [
    'Status', 'Total Cost ($)', 'Base Grand Total', 'Base Net Total', 'Base Total Taxes And Charges',
    'Quotation_Duration', 'Account Manager Name', 'Sales Manager Name', 'Discount Amount ($)',
    'Cost_to_Value_Ratio', 'Total Qty', 'Margin ($)', 'Price List Rate', 'Base Net Amount',
    'Item Cost ($)', 'Total Cost ($).1', 'Margin_Percentage', 'Discount_Percentage', 'Discount Percentage ($)'
]

# Filter df2 to keep only those columns (if they exist)
df4 = df2[[col for col in selected_columns if col in df2.columns]].copy()
```


```python
# Filtered dataset
df4.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Status</th>
      <th>Total Cost ($)</th>
      <th>Base Grand Total</th>
      <th>Base Net Total</th>
      <th>Base Total Taxes And Charges</th>
      <th>Quotation_Duration</th>
      <th>Account Manager Name</th>
      <th>Sales Manager Name</th>
      <th>Discount Amount ($)</th>
      <th>Cost_to_Value_Ratio</th>
      <th>Total Qty</th>
      <th>Margin ($)</th>
      <th>Price List Rate</th>
      <th>Base Net Amount</th>
      <th>Item Cost ($)</th>
      <th>Total Cost ($).1</th>
      <th>Margin_Percentage</th>
      <th>Discount_Percentage</th>
      <th>Discount Percentage ($)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>4611.67</td>
      <td>9063.36</td>
      <td>8392.0</td>
      <td>671.36</td>
      <td>132</td>
      <td>13</td>
      <td>1</td>
      <td>672.0</td>
      <td>0.274281</td>
      <td>5.0</td>
      <td>45.14</td>
      <td>2480.0</td>
      <td>3616.0</td>
      <td>991.80</td>
      <td>1983.60</td>
      <td>0.012483</td>
      <td>1694</td>
      <td>27.10</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>4611.67</td>
      <td>9063.36</td>
      <td>8392.0</td>
      <td>671.36</td>
      <td>132</td>
      <td>13</td>
      <td>1</td>
      <td>1456.0</td>
      <td>0.549739</td>
      <td>5.0</td>
      <td>45.03</td>
      <td>5320.0</td>
      <td>3864.0</td>
      <td>2124.19</td>
      <td>2124.19</td>
      <td>0.011654</td>
      <td>1757</td>
      <td>27.37</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>4611.67</td>
      <td>9063.36</td>
      <td>8392.0</td>
      <td>671.36</td>
      <td>132</td>
      <td>13</td>
      <td>1</td>
      <td>174.0</td>
      <td>0.276250</td>
      <td>5.0</td>
      <td>44.75</td>
      <td>630.0</td>
      <td>912.0</td>
      <td>251.94</td>
      <td>503.88</td>
      <td>0.049068</td>
      <td>1829</td>
      <td>27.62</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>4179.47</td>
      <td>8472.60</td>
      <td>7845.0</td>
      <td>627.60</td>
      <td>121</td>
      <td>23</td>
      <td>12</td>
      <td>1285.0</td>
      <td>0.533147</td>
      <td>2.0</td>
      <td>46.69</td>
      <td>5140.0</td>
      <td>3855.0</td>
      <td>2055.28</td>
      <td>2055.28</td>
      <td>0.012112</td>
      <td>1500</td>
      <td>25.00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>4179.47</td>
      <td>8472.60</td>
      <td>7845.0</td>
      <td>627.60</td>
      <td>121</td>
      <td>23</td>
      <td>12</td>
      <td>1330.0</td>
      <td>0.532378</td>
      <td>2.0</td>
      <td>46.76</td>
      <td>5320.0</td>
      <td>3990.0</td>
      <td>2124.19</td>
      <td>2124.19</td>
      <td>0.011719</td>
      <td>1500</td>
      <td>25.00</td>
    </tr>
  </tbody>
</table>
</div>



#### Logistic Regression


```python
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import LabelEncoder
import pandas as pd
```


```python
# Ensure target column exists
if 'Status' not in df4.columns:
    raise KeyError("'Status' column not found in df4")

# Separate features and target
X = df4.drop(columns=['Status'])
y = df4['Status']

# Encode target if it's categorical
if y.dtype == 'object':
    le = LabelEncoder()
    y = le.fit_transform(y)  # Now y will be 0s and 1s
```


```python
# Fill numeric NaNs with 0
X = X.fillna(0)
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
model = LogisticRegression(max_iter=1000)  # Increase max_iter if needed
model.fit(X_train, y_train)
```

    C:\Users\DELL\anaconda3\Lib\site-packages\sklearn\linear_model\_logistic.py:469: ConvergenceWarning: lbfgs failed to converge (status=1):
    STOP: TOTAL NO. of ITERATIONS REACHED LIMIT.
    
    Increase the number of iterations (max_iter) or scale the data as shown in:
        https://scikit-learn.org/stable/modules/preprocessing.html
    Please also refer to the documentation for alternative solver options:
        https://scikit-learn.org/stable/modules/linear_model.html#logistic-regression
      n_iter_i = _check_optimize_result(
    




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LogisticRegression(max_iter=1000)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;LogisticRegression<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.linear_model.LogisticRegression.html">?<span>Documentation for LogisticRegression</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>LogisticRegression(max_iter=1000)</pre></div> </div></div></div></div>




```python
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, mean_squared_error
import numpy as np

# Predict
y_pred = model.predict(X_test)

# Evaluation
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("\nAccuracy Score:")
print(accuracy_score(y_test, y_pred))

# RMSE Calculation
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\nRoot Mean Squared Error (RMSE): {rmse:.4f}")

```

    Confusion Matrix:
    [[    2  1958     0     0]
     [   20 16722     1    29]
     [    2   170     0     0]
     [    3  8897     0    12]]
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0       0.07      0.00      0.00      1960
               1       0.60      1.00      0.75     16772
               2       0.00      0.00      0.00       172
               3       0.29      0.00      0.00      8912
    
        accuracy                           0.60     27816
       macro avg       0.24      0.25      0.19     27816
    weighted avg       0.46      0.60      0.45     27816
    
    
    Accuracy Score:
    0.6016681046879494
    
    Root Mean Squared Error (RMSE): 1.1671
    

#### Decision Tree Classifier


```python
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, mean_squared_error
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
```


```python
# Ensure the 'Status' column exists
if 'Status' not in df4.columns:
    raise KeyError("'Status' column not found in df4")

# Separate features and target
X = df4.drop(columns=['Status'])
y = df4['Status']

# Encode target if categorical
if y.dtype == 'object':
    le = LabelEncoder()
    y = le.fit_transform(y)
```


```python
# Fill numeric missing values with 0
X = X.fillna(0)
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
dt_model = DecisionTreeClassifier(random_state=42)
dt_model.fit(X_train, y_train)
```




<style>#sk-container-id-2 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-2 {
  color: var(--sklearn-color-text);
}

#sk-container-id-2 pre {
  padding: 0;
}

#sk-container-id-2 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-2 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-2 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-2 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-2 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-2 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-2 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-2 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-2 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-2 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-2 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-2 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-2 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-2 div.sk-label label.sk-toggleable__label,
#sk-container-id-2 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-2 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-2 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-2 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-2 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-2 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-2 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-2 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-2 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-2 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>DecisionTreeClassifier(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;DecisionTreeClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.tree.DecisionTreeClassifier.html">?<span>Documentation for DecisionTreeClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>DecisionTreeClassifier(random_state=42)</pre></div> </div></div></div></div>




```python
# Make predictions
y_pred = dt_model.predict(X_test)

# Confusion Matrix
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Accuracy Score
print("\nAccuracy Score:")
print(accuracy_score(y_test, y_pred))

# RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\nRoot Mean Squared Error (RMSE): {rmse:.4f}")
```

    Confusion Matrix:
    [[ 1636    39    12   273]
     [   66 15403     3  1300]
     [   16     2   117    37]
     [  293  1412    49  7158]]
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0       0.81      0.83      0.82      1960
               1       0.91      0.92      0.92     16772
               2       0.65      0.68      0.66       172
               3       0.82      0.80      0.81      8912
    
        accuracy                           0.87     27816
       macro avg       0.80      0.81      0.80     27816
    weighted avg       0.87      0.87      0.87     27816
    
    
    Accuracy Score:
    0.8741012366983031
    
    Root Mean Squared Error (RMSE): 0.7643
    

#### Random Forest Classifier


```python
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, mean_squared_error
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import numpy as np
```


```python
# Ensure target column exists
if 'Status' not in df4.columns:
    raise KeyError("'Status' column not found in df4")

# Separate features and target
X = df4.drop(columns=['Status'])
y = df4['Status']

# Encode target if it's categorical
if y.dtype == 'object':
    le = LabelEncoder()
    y = le.fit_transform(y)
```


```python
X = X.fillna(0)
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```


```python
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
```




<style>#sk-container-id-3 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-3 {
  color: var(--sklearn-color-text);
}

#sk-container-id-3 pre {
  padding: 0;
}

#sk-container-id-3 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-3 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-3 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-3 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-3 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-3 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-3 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-3 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-3 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-3 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-3 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-3 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-3 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-3 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-3 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-3 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-3 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-3 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-3 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-3 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-3 div.sk-label label.sk-toggleable__label,
#sk-container-id-3 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-3 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-3 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-3 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-3 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-3 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-3 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-3 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-3 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-3 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-3 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-3 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" checked><label for="sk-estimator-id-3" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;RandomForestClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>RandomForestClassifier(random_state=42)</pre></div> </div></div></div></div>




```python
y_pred = rf_model.predict(X_test)

# Confusion Matrix
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Accuracy Score
print("\nAccuracy Score:")
print(accuracy_score(y_test, y_pred))

# RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\nRoot Mean Squared Error (RMSE): {rmse:.4f}")
```

    Confusion Matrix:
    [[ 1585    48     1   326]
     [   27 16215     0   530]
     [   16     1    97    58]
     [  156  1784     5  6967]]
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0       0.89      0.81      0.85      1960
               1       0.90      0.97      0.93     16772
               2       0.94      0.56      0.71       172
               3       0.88      0.78      0.83      8912
    
        accuracy                           0.89     27816
       macro avg       0.90      0.78      0.83     27816
    weighted avg       0.89      0.89      0.89     27816
    
    
    Accuracy Score:
    0.8938740293356342
    
    Root Mean Squared Error (RMSE): 0.7044
    


```python
feature_importances = pd.DataFrame({
    'Feature': X.columns,
    'Importance': rf_model.feature_importances_
}).sort_values(by='Importance', ascending=False)

print("\nFeature Importances:")
print(feature_importances)
```

    
    Feature Importances:
                             Feature  Importance
    4             Quotation_Duration    0.245722
    3   Base Total Taxes And Charges    0.064705
    0                 Total Cost ($)    0.064340
    2                 Base Net Total    0.063230
    1               Base Grand Total    0.062549
    9                      Total Qty    0.061147
    6             Sales Manager Name    0.058262
    5           Account Manager Name    0.046496
    10                    Margin ($)    0.044928
    16           Discount_Percentage    0.038274
    17       Discount Percentage ($)    0.036297
    8            Cost_to_Value_Ratio    0.035762
    12               Base Net Amount    0.032154
    15             Margin_Percentage    0.031544
    7            Discount Amount ($)    0.030241
    11               Price List Rate    0.029458
    14              Total Cost ($).1    0.028612
    13                 Item Cost ($)    0.026279
    


```python
rf_model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    min_samples_split=5,
    min_samples_leaf=2,
    random_state=42
)
rf_model.fit(X_train, y_train)
```




<style>#sk-container-id-4 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-4 {
  color: var(--sklearn-color-text);
}

#sk-container-id-4 pre {
  padding: 0;
}

#sk-container-id-4 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-4 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-4 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-4 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-4 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-4 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-4 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-4 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-4 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-4 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-4 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-4 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-4 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-4 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-4 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-4 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-4 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-4 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-4 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-4 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-4 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-4 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-4 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-4 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-4 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-4 div.sk-label label.sk-toggleable__label,
#sk-container-id-4 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-4 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-4 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-4 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-4 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-4 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-4 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-4 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-4 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-4 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-4 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-4 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-4 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-4" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(max_depth=10, min_samples_leaf=2, min_samples_split=5,
                       n_estimators=200, random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" checked><label for="sk-estimator-id-4" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;RandomForestClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>RandomForestClassifier(max_depth=10, min_samples_leaf=2, min_samples_split=5,
                       n_estimators=200, random_state=42)</pre></div> </div></div></div></div>



#### Support Vector Machine Application


```python
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, mean_squared_error
from sklearn.preprocessing import LabelEncoder, StandardScaler
import pandas as pd
import numpy as np
```


```python
# Check if 'Status' is in df4
if 'Status' not in df4.columns:
    raise KeyError("'Status' column is not found in df4.")

# Separate features and target
X = df4.drop(columns=['Status'])
y = df4['Status']

# Encode target if it's categorical
if y.dtype == 'object':
    le = LabelEncoder()
    y = le.fit_transform(y)
```


```python
# Fill missing values
X = X.fillna(0)

# Scale features (SVM performs better with scaled data)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
```


```python
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)
```


```python
svm_model = SVC(kernel='rbf', C=1.0, gamma='scale', random_state=42)
svm_model.fit(X_train, y_train)
```




<style>#sk-container-id-5 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-5 {
  color: var(--sklearn-color-text);
}

#sk-container-id-5 pre {
  padding: 0;
}

#sk-container-id-5 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-5 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-5 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-5 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-5 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-5 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-5 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-5 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-5 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-5 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-5 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-5 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-5 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-5 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-5 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-5 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-5 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-5 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-5 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-5 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-5 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-5 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-5 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-5 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-5 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-5 div.sk-label label.sk-toggleable__label,
#sk-container-id-5 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-5 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-5 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-5 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-5 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-5 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-5 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-5 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-5 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-5 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-5 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-5 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-5 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-5" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>SVC(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-5" type="checkbox" checked><label for="sk-estimator-id-5" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;SVC<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.svm.SVC.html">?<span>Documentation for SVC</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>SVC(random_state=42)</pre></div> </div></div></div></div>




```python
# Make predictions
y_pred = svm_model.predict(X_test)

# Confusion Matrix
print("Confusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Classification Report
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Accuracy Score
print("\nAccuracy Score:")
print(accuracy_score(y_test, y_pred))

# RMSE
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\nRoot Mean Squared Error (RMSE): {rmse:.4f}")
```

    Confusion Matrix:
    [[  452   813     0   695]
     [  101 15181     0  1490]
     [    4    87     0    81]
     [  199  5636     0  3077]]
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0       0.60      0.23      0.33      1960
               1       0.70      0.91      0.79     16772
               2       0.00      0.00      0.00       172
               3       0.58      0.35      0.43      8912
    
        accuracy                           0.67     27816
       macro avg       0.47      0.37      0.39     27816
    weighted avg       0.65      0.67      0.64     27816
    
    
    Accuracy Score:
    0.6726344549899339
    
    Root Mean Squared Error (RMSE): 1.1634
    

    C:\Users\DELL\anaconda3\Lib\site-packages\sklearn\metrics\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    C:\Users\DELL\anaconda3\Lib\site-packages\sklearn\metrics\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    C:\Users\DELL\anaconda3\Lib\site-packages\sklearn\metrics\_classification.py:1531: UndefinedMetricWarning: Precision is ill-defined and being set to 0.0 in labels with no predicted samples. Use `zero_division` parameter to control this behavior.
      _warn_prf(average, modifier, f"{metric.capitalize()} is", len(result))
    

#### Apply SMOTE for More Balanced & Ethical Model


```python
pip install imbalanced-learn
```

    Requirement already satisfied: imbalanced-learn in c:\users\dell\anaconda3\lib\site-packages (0.12.3)
    Requirement already satisfied: numpy>=1.17.3 in c:\users\dell\anaconda3\lib\site-packages (from imbalanced-learn) (1.26.4)
    Requirement already satisfied: scipy>=1.5.0 in c:\users\dell\anaconda3\lib\site-packages (from imbalanced-learn) (1.13.1)
    Requirement already satisfied: scikit-learn>=1.0.2 in c:\users\dell\anaconda3\lib\site-packages (from imbalanced-learn) (1.5.1)
    Requirement already satisfied: joblib>=1.1.1 in c:\users\dell\anaconda3\lib\site-packages (from imbalanced-learn) (1.4.2)
    Requirement already satisfied: threadpoolctl>=2.0.0 in c:\users\dell\anaconda3\lib\site-packages (from imbalanced-learn) (3.5.0)
    Note: you may need to restart the kernel to use updated packages.
    


```python
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
```


```python
df4 = df2[[col for col in selected_columns if col in df2.columns]].copy()
```


```python
# Ensure target column exists
if 'Status' not in df4.columns:
    raise KeyError("'Status' column not found in df4")

# Separate features and target
X = df4.drop(columns=['Status'])
y = df4['Status']

# Encode target if it's categorical
if y.dtype == 'object':
    le = LabelEncoder()
    y = le.fit_transform(y)
```


```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)
```


```python
smote = SMOTE(random_state=42)
X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)
```


```python
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train_smote, y_train_smote)
```




<style>#sk-container-id-6 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-6 {
  color: var(--sklearn-color-text);
}

#sk-container-id-6 pre {
  padding: 0;
}

#sk-container-id-6 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-6 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-6 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-6 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-6 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-6 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-6 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-6 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-6 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-6 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-6 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-6 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-6 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-6 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-6 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-6 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-6 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-6 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-6 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-6 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-6 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-6 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-6 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-6 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-6 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-6 div.sk-label label.sk-toggleable__label,
#sk-container-id-6 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-6 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-6 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-6 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-6 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-6 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-6 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-6 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-6 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-6 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-6 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-6 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-6 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-6" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-6" type="checkbox" checked><label for="sk-estimator-id-6" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;RandomForestClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>RandomForestClassifier(random_state=42)</pre></div> </div></div></div></div>




```python
y_pred = rf_model.predict(X_test)

print(classification_report(y_test, y_pred))
```

                  precision    recall  f1-score   support
    
               0       0.79      0.86      0.83      1967
               1       0.92      0.95      0.94     16704
               2       0.72      0.71      0.72       181
               3       0.88      0.81      0.84      8964
    
        accuracy                           0.90     27816
       macro avg       0.83      0.83      0.83     27816
    weighted avg       0.90      0.90      0.90     27816
    
    


```python
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, average='weighted'))
print("Recall:", recall_score(y_test, y_pred, average='weighted'))
print("F1 Score:", f1_score(y_test, y_pred, average='weighted'))
```

    Accuracy: 0.8979723899913719
    Precision: 0.8976238223666726
    Recall: 0.8979723899913719
    F1 Score: 0.8970743080822164
    

#### For more reliable and unbiased estimate and for model will well perform on unseen data use K-Fold CrossValidation


```python
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier

model = RandomForestClassifier(random_state=42)

# 5-Fold Cross Validation
scores = cross_val_score(model, X, y, cv=5, scoring='f1_weighted')  # or 'accuracy'

print("Cross-validated F1 scores:", scores)
print("Average F1 score:", scores.mean())
```

    Cross-validated F1 scores: [0.46869567 0.13430879 0.3814406  0.64295741 0.70721505]
    Average F1 score: 0.46692350460707244
    

#### Apply GridSearchCV to Random Forest


```python
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
```


```python
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5],
    'min_samples_leaf': [1, 2],
    'max_features': ['sqrt', 'log2']
}
```


```python
rf = RandomForestClassifier(random_state=42)
grid_search = GridSearchCV(estimator=rf, param_grid=param_grid,
                           cv=5, scoring='f1_weighted', n_jobs=-1)

grid_search.fit(X_train, y_train)
```




<style>#sk-container-id-7 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-7 {
  color: var(--sklearn-color-text);
}

#sk-container-id-7 pre {
  padding: 0;
}

#sk-container-id-7 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-7 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-7 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-7 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-7 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-7 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-7 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-7 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-7 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-7 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-7 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-7 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-7 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-7 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-7 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-7 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-7 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-7 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-7 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-7 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-7 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-7 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-7 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-7 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-7 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-7 div.sk-label label.sk-toggleable__label,
#sk-container-id-7 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-7 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-7 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-7 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-7 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-7 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-7 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-7 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-7 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-7 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-7 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-7 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-7 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-7" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>GridSearchCV(cv=5, estimator=RandomForestClassifier(random_state=42), n_jobs=-1,
             param_grid={&#x27;max_depth&#x27;: [10, 20, None],
                         &#x27;max_features&#x27;: [&#x27;sqrt&#x27;, &#x27;log2&#x27;],
                         &#x27;min_samples_leaf&#x27;: [1, 2],
                         &#x27;min_samples_split&#x27;: [2, 5],
                         &#x27;n_estimators&#x27;: [100, 200, 300]},
             scoring=&#x27;f1_weighted&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" ><label for="sk-estimator-id-7" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;GridSearchCV<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.model_selection.GridSearchCV.html">?<span>Documentation for GridSearchCV</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>GridSearchCV(cv=5, estimator=RandomForestClassifier(random_state=42), n_jobs=-1,
             param_grid={&#x27;max_depth&#x27;: [10, 20, None],
                         &#x27;max_features&#x27;: [&#x27;sqrt&#x27;, &#x27;log2&#x27;],
                         &#x27;min_samples_leaf&#x27;: [1, 2],
                         &#x27;min_samples_split&#x27;: [2, 5],
                         &#x27;n_estimators&#x27;: [100, 200, 300]},
             scoring=&#x27;f1_weighted&#x27;)</pre></div> </div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-8" type="checkbox" ><label for="sk-estimator-id-8" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">best_estimator_: RandomForestClassifier</label><div class="sk-toggleable__content fitted"><pre>RandomForestClassifier(n_estimators=300, random_state=42)</pre></div> </div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-9" type="checkbox" ><label for="sk-estimator-id-9" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;RandomForestClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a></label><div class="sk-toggleable__content fitted"><pre>RandomForestClassifier(n_estimators=300, random_state=42)</pre></div> </div></div></div></div></div></div></div></div></div>




```python
print("Best parameters:", grid_search.best_params_)
best_model = grid_search.best_estimator_
```

    Best parameters: {'max_depth': None, 'max_features': 'sqrt', 'min_samples_leaf': 1, 'min_samples_split': 2, 'n_estimators': 300}
    

#### Train a Random Forest Model for Predict the Quotation Lost Reason


```python
categories = df1['Lost Reason'].unique().tolist()
print(categories)
```

    [11, 1, 12, 2, 10, 3, 9, 0, 6, 8, 7, 4, 5]
    


```python
# Define the list of columns you want to keep
selected_columns = [
    'Status', 'Total Cost ($)', 'Base Grand Total', 'Base Net Total', 'Base Total Taxes And Charges',
    'Quotation_Duration', 'Account Manager Name', 'Sales Manager Name', 'Discount Amount ($)',
    'Cost_to_Value_Ratio', 'Total Qty', 'Margin ($)', 'Price List Rate', 'Base Net Amount',
    'Item Cost ($)', 'Total Cost ($).1', 'Margin_Percentage', 'Discount Percentage ($)', 'Lost Reason'
]

# Filter df2 to keep only those columns (if they exist)
df5 = df1[[col for col in selected_columns if col in df1.columns]].copy()
```


```python
from sklearn.preprocessing import LabelEncoder

# Create label encoders
le_account = LabelEncoder()
le_sales = LabelEncoder()

# Apply label encoding
df5['Account Manager Name'] = le_account.fit_transform(df5['Account Manager Name'].astype(str))
df5['Sales Manager Name'] = le_sales.fit_transform(df5['Sales Manager Name'].astype(str))
```


```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
```


```python
# Copy the dataset
data = df5.copy()

# Check if 'Lost Reason' column is present
if 'Lost Reason' not in data.columns:
    raise KeyError("'Lost Reason' column is not found in df5.")

# Separate target and features
y = data['Lost Reason']
X = data.drop(columns=['Lost Reason'])

# Encode categorical columns
label_encoders = {}
for col in X.columns:
    if X[col].dtype == 'object':
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str))
        label_encoders[col] = le

# Encode target (Lost Reason)
target_encoder = LabelEncoder()
y_encoded = target_encoder.fit_transform(y.astype(str))
```


```python
# Fill missing values (if any)
X = X.fillna(0)

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_encoded, test_size=0.2, random_state=42)
```


```python
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)
```




<style>#sk-container-id-8 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-8 {
  color: var(--sklearn-color-text);
}

#sk-container-id-8 pre {
  padding: 0;
}

#sk-container-id-8 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-8 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-8 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-8 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-8 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-8 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-8 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-8 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-8 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-8 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-8 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-8 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-8 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-8 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-8 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-8 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-8 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-8 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-8 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-8 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-8 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-8 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-8 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-8 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-8 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-8 div.sk-label label.sk-toggleable__label,
#sk-container-id-8 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-8 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-8 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-8 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-8 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-8 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-8 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-8 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-8 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-8 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-8 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-8 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-8 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-8" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier(random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-10" type="checkbox" checked><label for="sk-estimator-id-10" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;RandomForestClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>RandomForestClassifier(random_state=42)</pre></div> </div></div></div></div>




```python
y_pred = model.predict(X_test)

# Inverse transform to get original lost reason labels
y_test_labels = target_encoder.inverse_transform(y_test)
y_pred_labels = target_encoder.inverse_transform(y_pred)

# Print evaluation
print("Confusion Matrix:")
print(confusion_matrix(y_test_labels, y_pred_labels))

print("\nClassification Report:")
print(classification_report(y_test_labels, y_pred_labels))

print("\nAccuracy Score:")
print(accuracy_score(y_test_labels, y_pred_labels))
```

    Confusion Matrix:
    [[    2     0     0     0     0     0     1     0     0     0     0     0
          0]
     [    0   747     2    28    18     8   114     0     0     4     0     0
          0]
     [    0     7   621    72    52     9   116     0     0     4     0     0
          5]
     [    0    23    25 15902   131    20   257     2     0     1     1     1
          3]
     [    0    31    30   143  2569    75   496     3     0     8     5     1
          4]
     [    0    16    22    59   166   488   157     0     0     3     2     0
          6]
     [    0   123    66   199   409    42  3451     1     0    16     1     5
          3]
     [    0     0     0     1     7     2    29    74     0     0     1     2
          0]
     [    0     0     0     2     5     2    17     3    48     1     1     2
          0]
     [    0     1     2     3     5     7    26     0     0   205     1     0
         11]
     [    0     0     0     1    16     1    11     1     1     0    91     1
          1]
     [    0     0     4     2    28     2    36     3     1     2     1   128
          0]
     [    0     0    22     8    11    15    25     0     0    11     0     0
        159]]
    
    Classification Report:
                  precision    recall  f1-score   support
    
               0       1.00      0.67      0.80         3
               1       0.79      0.81      0.80       921
              10       0.78      0.70      0.74       886
              11       0.97      0.97      0.97     16366
              12       0.75      0.76      0.76      3365
               2       0.73      0.53      0.61       919
               3       0.73      0.80      0.76      4316
               4       0.85      0.64      0.73       116
               5       0.96      0.59      0.73        81
               6       0.80      0.79      0.79       261
               7       0.88      0.73      0.80       124
               8       0.91      0.62      0.74       207
               9       0.83      0.63      0.72       251
    
        accuracy                           0.88     27816
       macro avg       0.84      0.71      0.77     27816
    weighted avg       0.88      0.88      0.88     27816
    
    
    Accuracy Score:
    0.8802487776819097
    

#### Optimize the Quotation Success


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Plot frequency of each lost reason
plt.figure(figsize=(10, 5))
sns.countplot(data=df, y='Lost Reason', order=df['Lost Reason'].value_counts().index, palette='magma')
plt.title('Quotation Lost Reasons Distribution')
plt.xlabel('Count')
plt.ylabel('Lost Reason')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\347844743.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=df, y='Lost Reason', order=df['Lost Reason'].value_counts().index, palette='magma')
    


    
![png](output_107_1.png)
    



```python
import seaborn as sns
import matplotlib.pyplot as plt

# Plot frequency of each lost reason
plt.figure(figsize=(10, 5))
sns.countplot(data=df5, y='Lost Reason', order=df5['Lost Reason'].value_counts().index, palette='magma')
plt.title('Quotation Lost Reasons Distribution')
plt.xlabel('Count')
plt.ylabel('Lost Reason')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\1774164746.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.countplot(data=df5, y='Lost Reason', order=df5['Lost Reason'].value_counts().index, palette='magma')
    


    
![png](output_108_1.png)
    


#### Lost Reason is Out of Stock


```python
df1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 139080 entries, 0 to 139079
    Data columns (total 53 columns):
     #   Column                        Non-Null Count   Dtype         
    ---  ------                        --------------   -----         
     0   Name                          139080 non-null  object        
     1   Creation                      139080 non-null  datetime64[ns]
     2   Modified                      139080 non-null  datetime64[ns]
     3   Docstatus                     139080 non-null  int64         
     4   Customer Name                 139080 non-null  object        
     5   Transaction Date              139080 non-null  object        
     6   Address Display               139080 non-null  object        
     7   Customer Group                139080 non-null  int32         
     8   Total Qty                     139080 non-null  float64       
     9   Base Net Total                139080 non-null  float64       
     10  Base Total Taxes And Charges  139080 non-null  float64       
     11  Base Grand Total              139080 non-null  float64       
     12  Status                        139080 non-null  int32         
     13  Payment Type                  139080 non-null  int32         
     14  Total Cost ($)                139080 non-null  float64       
     15  Account Manager Name          139080 non-null  category      
     16  Sales Manager Name            139080 non-null  category      
     17  Department                    139080 non-null  category      
     18  Creation.1                    139080 non-null  object        
     19  Modified.1                    139080 non-null  object        
     20  Lost Reason                   139080 non-null  int32         
     21  Item Code                     139080 non-null  object        
     22  Item Name                     139080 non-null  object        
     23  Item Group                    139080 non-null  int32         
     24  Brand                         139080 non-null  int32         
     25  Qty                           139080 non-null  float64       
     26  Stock Uom                     139080 non-null  int32         
     27  Stock Qty                     139080 non-null  float64       
     28  Price List Rate               139080 non-null  float64       
     29  Discount Percentage ($)       139080 non-null  float64       
     30  Discount Amount ($)           139080 non-null  float64       
     31  Base Net Amount               139080 non-null  float64       
     32  Warehouse                     139080 non-null  object        
     33  Projected Qty                 139080 non-null  float64       
     34  Actual Qty                    139080 non-null  float64       
     35  Total Qty.1                   139080 non-null  float64       
     36  Item Vailability              139080 non-null  int32         
     37  Item Cost ($)                 139080 non-null  float64       
     38  Total Cost ($).1              139080 non-null  float64       
     39  Margin ($)                    139080 non-null  float64       
     40  Stocking Status               139080 non-null  int32         
     41  Quotation_Duration            139080 non-null  int64         
     42  Is_Loyal                      139080 non-null  int32         
     43  Customer_Loyalty_Score        139080 non-null  float64       
     44  Discount_Percentage           137094 non-null  object        
     45  Margin_Percentage             139080 non-null  float64       
     46  Cost_to_Value_Ratio           139080 non-null  float64       
     47  Is_Success                    139080 non-null  int32         
     48  Average_Item_Discount         139080 non-null  float64       
     49  Average_Item_Margin           139080 non-null  float64       
     50  Item_Success_Rate             139080 non-null  float64       
     51  Success_Rate                  139080 non-null  float64       
     52  Stock_Shortage                139080 non-null  float64       
    dtypes: category(3), datetime64[ns](2), float64(25), int32(11), int64(2), object(10)
    memory usage: 47.6+ MB
    


```python
out_of_stock_df = df1[df1['Lost Reason'] == 3]
```


```python
# Replace 'Item Name' with your actual item column
item_stock_issue_counts = out_of_stock_df.groupby('Item Name').size().reset_index(name='Out of Stock Count')

# Sort by highest impact
item_stock_issue_counts = item_stock_issue_counts.sort_values(by='Out of Stock Count', ascending=False)

# Show top 10 problematic items
print(item_stock_issue_counts.head(10))
```

             Item Name  Out of Stock Count
    1604  Others Sales                 651
    90        A9N16204                 274
    158       A9N4P63C                 210
    1361      LV429387                 204
    156       A9N4P32C                 195
    100       A9N16255                 192
    1142      LC1D09P7                 178
    115       A9N1P16C                 169
    157       A9N4P40C                 168
    134       A9N2P32C                 167
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 6))
sns.barplot(data=item_stock_issue_counts.head(15), x='Out of Stock Count', y='Item Name', palette='rocket')
plt.title('Top Items Lost Due to Out of Stock')
plt.xlabel('Number of Quotations Lost')
plt.ylabel('Item Name')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\1171883274.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=item_stock_issue_counts.head(15), x='Out of Stock Count', y='Item Name', palette='rocket')
    


    
![png](output_113_1.png)
    


#### Lost Reason is Price


```python
price_lost_df = df1[df1['Lost Reason'] == 12]
```


```python
customer_price_loss = price_lost_df.groupby('Customer Name').size().reset_index(name='Lost Due to Price')

# Sort descending
customer_price_loss = customer_price_loss.sort_values(by='Lost Due to Price', ascending=False)

# Display top customers
print(customer_price_loss.head(10))
```

                                    Customer Name  Lost Due to Price
    99                          CASH SALE - OMESH                551
    51                    Ansell Lanka (Pvt) Ltd.                366
    133                       Cash Sales-Buddhika                343
    461  Maliban Biscuit Manufactories (Pvt) Ltd.                249
    539                  Ocean Lanka ( Pvt ) Ltd.                238
    431                        Linaya Enterprises                227
    105        CBL Foods International (Pvt) Ltd.                215
    705               South Asia Textiles Limited                204
    294        Global Rubber Industries (Pvt) Ltd                196
    238        Earthfoam (Pvt) Ltd.\t\t\t\t\t\t\t                189
    


```python
# Calculate average discount per customer
if 'Discount_Percentage' in df1.columns:
    avg_discount = price_lost_df.groupby('Customer Name')['Discount_Percentage'].mean().reset_index(name='Avg Discount (%)')

    # Merge with lost count
    customer_discount_analysis = pd.merge(customer_price_loss, avg_discount, on='Customer Name')

    # Prioritize: High loss count and low discount
    customer_discount_analysis['Priority Score'] = customer_discount_analysis['Lost Due to Price'] / (customer_discount_analysis['Avg Discount (%)'] + 1)
    
    # Sort by priority
    top_customers_to_incentivize = customer_discount_analysis.sort_values(by='Priority Score', ascending=False)

    print(top_customers_to_incentivize.head(10))
```

                                   Customer Name  Lost Due to Price  \
    0                          CASH SALE - OMESH                551   
    1                    Ansell Lanka (Pvt) Ltd.                366   
    2                        Cash Sales-Buddhika                343   
    3   Maliban Biscuit Manufactories (Pvt) Ltd.                249   
    4                   Ocean Lanka ( Pvt ) Ltd.                238   
    5                         Linaya Enterprises                227   
    6         CBL Foods International (Pvt) Ltd.                215   
    8         Global Rubber Industries (Pvt) Ltd                196   
    7                South Asia Textiles Limited                204   
    13           Macksons Tiles Lanka (Pvt) Ltd.                163   
    
       Avg Discount (%) Priority Score  
    0          0.281319     430.025592  
    1          0.264057      289.54385  
    2          0.287791     266.347478  
    3          0.309438     190.157951  
    4          0.315572     180.909896  
    5          0.299427     174.692342  
    6          0.247107     172.398971  
    8          0.194492     164.086442  
    7           0.30027     156.890539  
    13         0.147712     142.021636  
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 6))
sns.barplot(data=customer_price_loss.head(10), x='Lost Due to Price', y='Customer Name', palette='flare')
plt.title('Top Customers Lost Due to Price')
plt.xlabel('Number of Quotations Lost')
plt.ylabel('Customer Name')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3994627200.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=customer_price_loss.head(10), x='Lost Due to Price', y='Customer Name', palette='flare')
    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3994627200.py:9: UserWarning: Glyph 9 (	) missing from font(s) DejaVu Sans.
      plt.tight_layout()
    C:\Users\DELL\anaconda3\Lib\site-packages\IPython\core\pylabtools.py:170: UserWarning: Glyph 9 (	) missing from font(s) DejaVu Sans.
      fig.canvas.print_figure(bytes_io, **kw)
    


    
![png](output_118_1.png)
    


#### Lost Reason is Other Brand


```python
lost_other_brand_df = df1[df1['Lost Reason'] == 2]
```


```python
# Replace 'Item Name' with your actual item column
item_loss_counts = lost_other_brand_df.groupby('Item Name').size().reset_index(name='Lost to Other Brand Count')

# Sort items by how often they were lost
item_loss_counts = item_loss_counts.sort_values(by='Lost to Other Brand Count', ascending=False)

# Show top items
print(item_loss_counts.head(10))
```

             Item Name  Lost to Other Brand Count
    812   Others Sales                        142
    51        A9N16204                         83
    68        A9N1P10C                         69
    69        A9N1P16C                         58
    599       LC1D09P7                         54
    82        A9N2P32C                         52
    100       A9N4P63C                         45
    67        A9N1P06C                         44
    99        A9N4P40C                         44
    1082     XB7EV04MP                         43
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(12, 6))
sns.barplot(data=item_loss_counts.head(10), x='Lost to Other Brand Count', y='Item Name', palette='crest')
plt.title('Top Items Lost Due to Other Brand')
plt.xlabel('Number of Quotations Lost')
plt.ylabel('Item Name')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\1644730766.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=item_loss_counts.head(10), x='Lost to Other Brand Count', y='Item Name', palette='crest')
    


    
![png](output_122_1.png)
    


#### Lost Reason is Lead Time


```python
lead_time_lost_df = df1[df1['Lost Reason'] == 1]
```


```python
# Group by Account Manager
account_manager_counts = lead_time_lost_df.groupby('Account Manager Name').size().reset_index(name='Lost Due to Lead Time')

# Group by Sales Manager
sales_manager_counts = lead_time_lost_df.groupby('Sales Manager Name').size().reset_index(name='Lost Due to Lead Time')
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3775997522.py:2: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      account_manager_counts = lead_time_lost_df.groupby('Account Manager Name').size().reset_index(name='Lost Due to Lead Time')
    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3775997522.py:5: FutureWarning: The default of observed=False is deprecated and will be changed to True in a future version of pandas. Pass observed=False to retain current behavior or observed=True to adopt the future default and silence this warning.
      sales_manager_counts = lead_time_lost_df.groupby('Sales Manager Name').size().reset_index(name='Lost Due to Lead Time')
    


```python
# Sort descending
account_manager_counts = account_manager_counts.sort_values(by='Lost Due to Lead Time', ascending=False)
sales_manager_counts = sales_manager_counts.sort_values(by='Lost Due to Lead Time', ascending=False)

print("Top Account Managers with Lead Time Losses:")
print(account_manager_counts.head(3))

print("\nTop Sales Managers with Lead Time Losses:")
print(sales_manager_counts.head(3))
```

    Top Account Managers with Lead Time Losses:
       Account Manager Name  Lost Due to Lead Time
    31         Suresh Kumar                   2927
    2     Bala Subramaniyam                    420
    13       Jayalath Kamal                    326
    
    Top Sales Managers with Lead Time Losses:
          Sales Manager Name  Lost Due to Lead Time
    12      Pradeep Chaminda                   2402
    1        Anoja Vithanage                    837
    4   Chathuranga Sanjeewa                    748
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Account Managers
plt.figure(figsize=(12, 5))
sns.barplot(data=account_manager_counts.head(3), x='Lost Due to Lead Time', y='Account Manager Name', palette='rocket')
plt.title('Top Account Managers - Lead Time Losses')
plt.xlabel('Number of Quotations Lost')
plt.ylabel('Account Manager')
plt.tight_layout()
plt.show()

# Sales Managers
plt.figure(figsize=(12, 5))
sns.barplot(data=sales_manager_counts.head(3), x='Lost Due to Lead Time', y='Sales Manager Name', palette='mako')
plt.title('Top Sales Managers - Lead Time Losses')
plt.xlabel('Number of Quotations Lost')
plt.ylabel('Sales Manager')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\138199716.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=account_manager_counts.head(3), x='Lost Due to Lead Time', y='Account Manager Name', palette='rocket')
    


    
![png](output_127_1.png)
    


    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\138199716.py:15: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=sales_manager_counts.head(3), x='Lost Due to Lead Time', y='Sales Manager Name', palette='mako')
    


    
![png](output_127_3.png)
    


#### Lost Reason is Technical Issue


```python
tech_issues_df = df1[df1['Lost Reason'] == 10]
```


```python
# Group by customer
customer_issues = tech_issues_df.groupby('Customer Name').size().reset_index(name='Tech Issue Loss Count')

# Sort in descending order
customer_issues = customer_issues.sort_values(by='Tech Issue Loss Count', ascending=False)

# View top customers
print(customer_issues.head(10))
```

                                   Customer Name  Tech Issue Loss Count
    68                        Cash Sales-Pasindu                    672
    142       Global Rubber Industries (Pvt) Ltd                    198
    321             Teclan Engineering (Pvt) Ltd                    177
    294            Siam City Cement (Lanka) Ltd.                    159
    23          Ansell Textiles Lanka (Pvt) Ltd.                    134
    86         Cool Man Refrigeration (Pvt) Ltd.                    110
    281                 S M T Apparel Lanka Ltd.                     99
    16           Airport & Aviation (Katunayaka)                     90
    297  Silvermill Natural Beverages (Pvt) Ltd.                     86
    148                            HSK Solutions                     82
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(12, 6))
sns.barplot(data=customer_issues.head(10), x='Tech Issue Loss Count', y='Customer Name', palette='flare')
plt.title('Top Customers Associated with Technical Issue Losses')
plt.xlabel('Number of Quotations Lost')
plt.ylabel('Customer Name')
plt.tight_layout()
plt.show()
```

    C:\Users\DELL\AppData\Local\Temp\ipykernel_21368\3799313934.py:5: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(data=customer_issues.head(10), x='Tech Issue Loss Count', y='Customer Name', palette='flare')
    


    
![png](output_131_1.png)
    


#### Put Weights on Attributes to Quotation Success


```python
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

# Step 1: Define your feature columns and target
features = [
    'Total Cost ($)', 'Base Grand Total', 'Base Net Total', 'Base Total Taxes And Charges',
    'Quotation_Duration', 'Account Manager Name', 'Sales Manager Name', 'Discount Amount ($)',
    'Cost_to_Value_Ratio', 'Total Qty', 'Margin ($)', 'Price List Rate', 'Base Net Amount',
    'Item Cost ($)', 'Total Cost ($).1', 'Margin_Percentage', 'Discount Percentage ($)'
]

target = 'Status'

# Step 2: Preprocess the data
df_encoded = df5.copy()

# Convert features to numeric (including handling categorical features)
for col in features:
    if df_encoded[col].dtype == 'object':
        le = LabelEncoder()
        df_encoded[col] = le.fit_transform(df_encoded[col].astype(str))
    else:
        df_encoded[col] = pd.to_numeric(df_encoded[col], errors='coerce').fillna(0)

# Encode target if it's not numeric
if df_encoded[target].dtype == 'object':
    df_encoded[target] = LabelEncoder().fit_transform(df_encoded[target].astype(str))

# Step 3: Train Random Forest to get feature importances
X = df_encoded[features]
y = df_encoded[target]

model = RandomForestClassifier(random_state=42)
model.fit(X, y)

# Step 4: Extract and display feature importances (as weights)
importances = model.feature_importances_
feature_weights = pd.DataFrame({
    'Feature': features,
    'Weight': importances
}).sort_values(by='Weight', ascending=False)

# Normalize weights to make them percentages (optional)
feature_weights['Weight (%)'] = feature_weights['Weight'] * 100

# Show result
print(feature_weights)
```

                             Feature    Weight  Weight (%)
    4             Quotation_Duration  0.253548   25.354844
    3   Base Total Taxes And Charges  0.067981    6.798055
    0                 Total Cost ($)  0.067786    6.778621
    2                 Base Net Total  0.065933    6.593269
    9                      Total Qty  0.064808    6.480759
    1               Base Grand Total  0.064740    6.473971
    6             Sales Manager Name  0.059787    5.978677
    16       Discount Percentage ($)  0.049107    4.910672
    5           Account Manager Name  0.047891    4.789122
    10                    Margin ($)  0.046349    4.634907
    8            Cost_to_Value_Ratio  0.035491    3.549070
    12               Base Net Amount  0.032020    3.202015
    15             Margin_Percentage  0.031118    3.111793
    7            Discount Amount ($)  0.031092    3.109166
    11               Price List Rate  0.029508    2.950812
    14              Total Cost ($).1  0.027479    2.747895
    13                 Item Cost ($)  0.025364    2.536353
    


```python

```
